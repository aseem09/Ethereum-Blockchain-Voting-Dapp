package com.example.voting;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Candidate_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.candidate_profile);
        final Candidate C = (Candidate)getIntent().getSerializableExtra("Candidate object");
        ImageView imageView=findViewById(R.id.candidate_pic);
        TextView name = findViewById(R.id.candidate_name);
        TextView post = findViewById(R.id.post);
        TextView agenda = findViewById(R.id.agenda);
        imageView.setImageResource(R.drawable.me);
        name.setText(C.getName());
        post.setText(C.getType());
        agenda.setText(C.getAgenda());

    }
}