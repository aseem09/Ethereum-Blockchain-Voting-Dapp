package com.example.voting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.voting.Converter;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private String readFromFile(Context context) {

        String ret = "";

        try {
            AssetManager assetManager = getAssets();
            InputStream inputStream = assetManager.open("Candidate_data.json");

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String jsonString=readFromFile(this);
        CandidateData data;
       try{ data = Converter.fromJsonString(jsonString);}
       catch (IOException e)
       {
           data= new CandidateData();
       }
        final Candidate C[]=data.getCandidate();

    Button button1=findViewById(R.id.tv_name);

    button1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(getBaseContext(), Select_type.class);
            intent.putExtra("EXTRA_SESSION_ID", C);
            startActivity(intent);
        }
    });
        Button button = findViewById(R.id.tv_headline);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                    Uri webpage = Uri.parse("http://bhawanvotingapp.app.sdslabs.tech/");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                PackageManager packageManager = getPackageManager();
                List<ResolveInfo> activities = packageManager.queryIntentActivities(webIntent, 0);
                boolean isIntentSafe = activities.size() > 0;

// Start an activity if it's safe
                if (isIntentSafe) {
                    startActivity(webIntent);
                }


            }
        });


    }

}
