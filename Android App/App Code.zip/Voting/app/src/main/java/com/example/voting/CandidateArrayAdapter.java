package com.example.voting;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CandidateArrayAdapter extends ArrayAdapter<Candidate> {
    public CandidateArrayAdapter(Context context, ArrayList<Candidate> users) {
        super(context, 0, users);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.candidate, parent, false);
        }

        // Get the {@link AndroidFlavor} object located at this position in the list
        Candidate currentCandidate = getItem(position);

        // Find the TextView in the list_item.xml layout with the ID version_name
        TextView nameTextView = (TextView) listItemView.findViewById(R.id.candidate_name);
        // Get the version name from the current AndroidFlavor object and
        // set this text on the name TextView
        nameTextView.setText(currentCandidate.getName());

        // Find the TextView in the list_item.xml layout with the ID version_number
//        TextView numberTextView = (TextView) listItemView.findViewById(R.id.version_number);
//        // Get the version number from the current AndroidFlavor object and
//        // set this text on the number TextView
//        numberTextView.setText(currentCandidate.getVersionNumber());

        // Find the ImageView in the list_item.xml layout with the ID list_item_icon
        ImageView picImageView = (ImageView) listItemView.findViewById(R.id.candidate_pic);
        // Get the image resource ID from the current AndroidFlavor object and
        // set the image to iconView

        picImageView.setImageResource(R.drawable.me);

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        return listItemView;
    }
}
