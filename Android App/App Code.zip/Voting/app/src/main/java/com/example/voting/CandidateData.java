package com.example.voting;

import java.util.*;
import com.fasterxml.jackson.annotation.*;

public class CandidateData {
    private Candidate[] candidate;

    @JsonProperty("Candidate")
    public Candidate[] getCandidate() { return candidate; }
    @JsonProperty("Candidate")
    public void setCandidate(Candidate[] value) { this.candidate = value; }
}