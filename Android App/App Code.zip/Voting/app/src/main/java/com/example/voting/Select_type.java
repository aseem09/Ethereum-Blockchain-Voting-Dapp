package com.example.voting;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Select_type extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.posts);



        final Candidate[] C = (Candidate[])getIntent().getSerializableExtra("EXTRA_SESSION_ID");
        final Button technical=findViewById(R.id.technical);
        Button maintenance=findViewById(R.id.maintenance);
        Button cultural=findViewById(R.id.cultural);
        Button sports=findViewById(R.id.sports);
        Button bhawan=findViewById(R.id.bhawan);
        Button mess=findViewById(R.id.mess);

       technical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","technical");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
        maintenance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","maintenance");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
        cultural.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","cultural");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
        bhawan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","bhawan");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
        mess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","mess");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
        sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity1.class);
                Bundle extras = new Bundle();
                extras.putSerializable("Candidates",C);
                extras.putString("Type","sports");
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
    }
}