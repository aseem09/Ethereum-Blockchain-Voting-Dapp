package com.example.voting;

import java.io.Serializable;
import java.util.*;
import com.fasterxml.jackson.annotation.*;

public class Candidate implements Serializable {
    private String name;
    private String agenda;
    private String poster;
    private String hostel;
    private String pic;
    private String type;
//    Candidate(String name,String agenda,String posterId,String type, String hostel, String picId)
//    {
//        this.name = name;
//        this.agenda = agenda;
//        this.poster = posterId;
//        this.pic=picId;
//        this.type = type;
//        this.hostel = hostel;
//
//    }
    @JsonProperty("name")
    public String getName() { return name; }
    @JsonProperty("name")
    public void setName(String value) { this.name = value; }

    @JsonProperty("Agenda")
    public String getAgenda() { return agenda; }
    @JsonProperty("Agenda")
    public void setAgenda(String value) { this.agenda = value; }

    @JsonProperty("poster")
    public String getPoster() { return poster; }
    @JsonProperty("poster")
    public void setPoster(String value) { this.poster = value; }

    @JsonProperty("hostel")
    public String getHostel() { return hostel; }
    @JsonProperty("hostel")
    public void setHostel(String value) { this.hostel = value; }

    @JsonProperty("pic")
    public String getPic() { return pic; }
    @JsonProperty("pic")
    public void setPic(String value) { this.pic = value; }

    @JsonProperty("type")
    public String getType() { return type; }
    @JsonProperty("type")
    public void setType(String value) { this.type = value; }
}