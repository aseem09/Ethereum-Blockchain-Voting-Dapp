package com.example.voting;

//import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity1 extends AppCompatActivity {
    public static boolean stringCompare(String str1, String str2)
    {

        int l1 = str1.length();
        int l2 = str2.length();
        int lmin = Math.min(l1, l2);

        for (int i = 0; i < lmin; i++) {
            int str1_ch = (int)str1.charAt(i);
            int str2_ch = (int)str2.charAt(i);

            if (str1_ch != str2_ch) {
                return false;
            }
        }

        // Edge case for strings like
        // String 1="Geeks" and String 2="Geeksforgeeks"
        if (l1 != l2) {
            return false;
        }

        // If none of the above conditions is true,
        // it implies both the strings are equal
        else {
            return true;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_candidates);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        String type = extras.getString("Type");
        final Candidate[] C = (Candidate[])extras.getSerializable("Candidates");
        final ArrayList<Candidate> candidates = new ArrayList<Candidate>();
//        candidates.add(new Candidate("ma ka lauda","cunt","fh","pata ni","rajiv","fg"));
//        candidates.add(new Candidate("ma ka lauda2","cunt2","df","pata ni","rajiv","sgd"));
//        candidates.add(new Candidate("ma ka lauda3","cunt","dgf","pata ni","rajiv","hdxh"));
       for(int i=0;i< Array.getLength(C);i++) {
           try {if(stringCompare(C[i].getHostel(),"Rajiv Bhawan")&&stringCompare(C[i].getType(),type))
               candidates.add(C[i]);
           } catch (NullPointerException e) {
//            candidates.add(new Candidate("3","cunt","dgf","pata ni","rajiv","hdxh"));
           }
       }
        CandidateArrayAdapter candidateArrayAdapter = new CandidateArrayAdapter(this,candidates);
        ListView listView = (ListView) findViewById(R.id.candidate_list);
        listView.setAdapter(candidateArrayAdapter);
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> a, View v, int position,
//                                    long id) {
//
//                Intent intent = new Intent(getBaseContext(), Candidate_profile.class);
//                intent.putExtra("Candidate object", candidates.get(position));
//                startActivity(intent);
//            }
//        });
    }
}
